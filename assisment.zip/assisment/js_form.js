
function validate(){
    
    // console.log(dob)
    dobvalidate()
    passmatch()
    }
function dobvalidate(){
// alert("into function")
var dob=document.getElementById('dob').value
// console.log(dob)
var yeardob=new Date(dob).getFullYear()

var currentyear=new Date().getFullYear()
var yeardiff=(currentyear-yeardob)
var monthdob=new Date(dob).getMonth()
var todaymonth=new Date().getMonth()
var monthdiff=(todaymonth-monthdob)
var todaydate=new Date().getDate()
var dobdate=new Date(dob).getDate()
var datediff=(todaydate-dobdate)
console.log(yeardiff)
console.log(monthdiff)
console.log(datediff)
console.log(currentyear)
console.log(yeardob)

    if(yeardiff>18)
    {alert('you r in!')}
    else if(yeardiff==18)
    {
        if(monthdiff>0)
        {
            alert('you are  18+')

        }
        else if(monthdiff<0)
        {
        alert("you not are 18+ but its your 18th year")
        }
        else{
            if(datediff>0){
                alert('its your bday month and you r 18!')
            }
            else{
                alert('its your bday month but you still to get 18')
            }
        }
    }
}
function passmatch(){
    var pass1=document.getElementById('pass1').value
var pass2=document.getElementById('pass2').value

if(pass1==pass2)
{
    alert("password matched");
}
else
{
    alert("password unmatched");

}
}
// $(document).ready(function (){
// $('submitbtn').click(function(){
//     if($('div.checkbox-group.required :checkbox:checked').length == 0)
//     alert("pls select lang")
// })
// })
